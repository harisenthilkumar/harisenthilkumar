from django.contrib import admin
from .models import Employee
from .models import All_Complaints
# Register your models here.

admin.site.register(Employee)
admin.site.register(All_Complaints)
