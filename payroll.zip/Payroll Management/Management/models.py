from django.db import models

# Create your models here.
class Employee(models.Model):
    Name = models.CharField(max_length=64)
    Email = models.CharField(max_length=64)
    Password = models.CharField(max_length=64)
    Position = models.CharField(max_length=64)
    Salary = models.IntegerField()


    def __str__(self):
        return f"{self.id}: {self.Name} is {self.Position} with salary of {self.Salary}. Email:{self.Email} and Password:{self.Password}"

#complaint
class All_Complaints(models.Model):
    name = models.CharField(max_length=100)
    sender = models.CharField(max_length=64)
    c_type = models.CharField(max_length=64)
    subject = models.CharField(max_length=64)
    message = models.CharField(max_length=300)

    def __str__(self):
        return f"{self.name} | {self.sender} | {self.c_type} | {self.subject} | {self.message}"